const splash = () => {
    document.getElementById("progress").style.display = "none";
  };

  document.getElementById("marker").addEventListener("markerFound", (e) => {
    document.getElementById("marker-loader-base").style.display = "none";
  });